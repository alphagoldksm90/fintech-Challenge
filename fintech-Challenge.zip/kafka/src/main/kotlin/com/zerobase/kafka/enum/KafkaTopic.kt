package com.zerobase.kafka.enum

enum class KafkaTopic(val topicName: String) {
    LOAN_REQUEST("loan_request");
}