rootProject.name = "fintech2023"
include("api")
include("consumer")
include("css")
include("domain")
include("kafka")
